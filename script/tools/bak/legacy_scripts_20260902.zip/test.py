from patch_tool import trans_patch
from stbtran_utils import get_category_list
import para_api
import json_tools
import stbtran_utils
import json
from parser_settings import files_of_interest
from sync_to_paratrans import walk_files
import os
patch_serialization = {
    "craftingmedical.object.patch": {"upgradeStages": {"index": 2, "increase": False}},
    "statuses.config.patch": {
        "generic": {"index": 70, "increase": True},
        "cheerful": {"index": 31, "increase": True},
        "jerk": {"index": 31, "increase": True},
        "flirty": {"index": 31, "increase": True},
        "anxious": {"index": 31, "increase": True},
        "easilyspooked": {"index": 32, "increase": True},
        "clumsy": {"index": 31, "increase": True},
        "excited": {"index": 31, "increase": True},
        "intrusive": {"index": 31, "increase": True},
        "dumb": {"index": 32, "increase": True},
        "emo": {"index": 30, "increase": True},
        "fast": {"index": 31, "increase": True},
        "nocturnal": {"index": 32, "increase": True},
        "socialite": {"index": 31, "increase": True},
        "ambitious": {"index": 30, "increase": True},
    },
    "craftingfurnace.object.patch": {"upgradeStages": {"index": 2, "increase": False}},
    "craftingwheel.object.patch": {"upgradeStages": {"index": 2, "increase": False}},
}
#print(trans_patch(open("F:\workplace\FrackinUniverse\objects/crafting/upgradeablecraftingobjects/craftingfurnace/craftingfurnace.object.patch", "r", encoding="utf_8_sig"),ex = patch_serialization.get("craftingmedical.object.patch")))
#print(get_category_list("F:\workplace\FrackinUniverse",[]))
#print(online_list["quests/fu_questlines/battle/gear/plebiancap.questtemplate.patch"])
#print(json_tools.prepare(open("F:\workplace\FrackinUniverse\quests/fu_questlines/battle\gear\plebiancap.questtemplate","r",encoding="utf-8-sig")))
"""
print(stbtran_utils.parseFile(
    "F:\workplace\FrackinUniverse\objects/crafting/upgradeablecraftingobjects/craftingfurnace/craftingfurnace.object.patch",
    files_of_interest,
    "",
    [],
    [],
    patch_serialization,
    show_fname=False,
))
"""
#online_list = {i["name"]: i["id"] for i in para_api.file_list(7650, "cd11860c565ed926ea5b2aa41697fd57")}
local_list= walk_files("F:/workplace/FrackinUniverse")
for i in  local_list:
    if len(i.split("/"))<=1:
        print(i) 
        print(os.path.abspath(i))
        print(os.path.join("F:/workplace/FrackinUniverse", i))